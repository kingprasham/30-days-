<?php
/**
 * Logout Handler
 * Customer Tracking & Billing Management System
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/auth.php';

processLogout();
